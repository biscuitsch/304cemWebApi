const frisby = require('frisby')

it('POST should return a status of 200 Created', function () {
  return frisby
    .post('http://localhost:3000/api/addChatbot', {
      year: '9',
      name: '9',
      creator: '9',
      developTool: '9',
      description: '9',
      website: '9',
      award: '9',
      remark: '9'
    })
    .expect('status', 200)
})
