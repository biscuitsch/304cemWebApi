const frisby = require('frisby')

it('PUT should return a status of 200 Created', function () {
  return frisby
    .put('http://localhost:3000/api/updateEvent/5cb562ded7f6c569b4e40b3f', {
      date: '6',
      name: '6',
      organizer: '5',
      place: '5',
      description: '5',
      website: '6',
      remark: '6'
    })
    .expect('status', 200)
})
