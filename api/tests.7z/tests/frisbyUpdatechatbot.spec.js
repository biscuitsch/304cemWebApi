const frisby = require('frisby')

it('PUT should return a status of 200 Created', function () {
  return frisby
    .put('http://localhost:3000/api/updateChatbot/5cb5b44b55bb9328e8130fda', {
      year: '9',
      name: '9',
      creator: '8',
      developTool: '8',
      description: '8',
      website: '9',
      award: '9',
      remark: '9'
    })
    .expect('status', 200)
})
