const frisby = require('frisby')

it('Delete should return a status of 200 Created', function () {
  return frisby
    .delete('http://localhost:3000/api/delEvent/5cb43feb9a02213ca02a6e9f')
    .expect('status', 200)
})
