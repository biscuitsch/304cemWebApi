const frisby = require('frisby')

it('Delete should return a status of 200 Created', function () {
  return frisby
    .delete('http://localhost:3000/api/delChatbot/5cb5b44b55bb9328e8130fda')
    .expect('status', 200)
})
