const frisby = require('frisby')

it('POST should return a status of 200 Created', function () {
  return frisby
    .post('http://localhost:3000/api/addEvent', {
      date: '6',
      name: '6',
      organizer: '6',
      place: '6',
      description: '6',
      website: '6',
      remark: '6'
    })
    .expect('status', 200)
})
