<template>
  <div>
<!-- set heading style -->  
    <h1 style="color:#00CC00"><u>Edit Event</u></h1>
    <br>
<!-- set edit form -->      
    <form @submit.prevent="updateEvent">
      <div class="row">
        <div class="col-md-12">
          <div class="form-group">
            <label>Date:</label>
            <input type="text" class="form-control" v-model="event.date" placeholder="Enter date">
          </div>
        </div>
        </div>
       <div class="row">       
        <div class="col-md-12">
          <div class="form-group">
            <label>Name:</label>
            <input type="text" class="form-control" v-model="event.name" placeholder="Enter name">
          </div>
        </div>
        </div>
       <div class="row">  
        <div class="col-md-12">
          <div class="form-group">
            <label>Organizer:</label>
            <input type="text" class="form-control" v-model="event.organizer" placeholder="Enter organizer">
          </div>
        </div>
        </div>
       <div class="row">  
        <div class="col-md-12">
          <div class="form-group">
            <label>Place:</label>
            <input type="text" class="form-control" v-model="event.place" placeholder="Enter development place">
          </div>
        </div>
        </div>
       <div class="row">  
        <div class="col-md-12">
          <div class="form-group">
            <label>Description:</label>
            <input type="text" class="form-control" v-model="event.description" placeholder="Enter description">
          </div>
        </div>
        </div>
       <div class="row">  
        <div class="col-md-12">
          <div class="form-group">
            <label>Web Site:</label>
            <input type="text" class="form-control" v-model="event.website" placeholder="Enter website">
          </div>
        </div>
        </div>        
       <div class="row">          
        <div class="col-md-12">
          <div class="form-group">
            <label>Remark:</label>
            <input type="text" class="form-control" v-model="event.remark" placeholder="Enter remark">
          </div>
        </div>
        </div><br />
        <div class="form-group">
          <button class="btn btn-success" @click.prevent="updateEvent()">Update</button>
        </div>
    </form>
  </div>
</template>

<script>
   
    export default {
      data() {
        return {
          event: {}
        }
      },
      created() {
// get data from uri to create page        
        let uri = `http://localhost:3000/api/editEvent/${this.$route.params.id}`;
        this.axios.get(uri).then((response) => { 
          this.event = response.data;  
        })      
      },
      methods: {
        updateEvent() {
// post data to uri to update record
          let uri = `http://localhost:3000/api/updateEvent/${this.$route.params.id}`;
          this.axios.put(uri, this.event).then(() => {
            this.$message({
                type: 'success',
                message: 'Edit succeeded.'
            })  
// redirect to event list page after record update
            this.$router.push({name: 'events'});
          });
        }
      }
    }
</script>