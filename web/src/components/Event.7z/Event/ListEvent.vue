<template>
  <div>
<!-- set heading style -->
      <h1 style="color:#00CC00"><u>EVENT LIST</u></h1>
        <div class="row">
          <div class="col-md-10"></div>
        </div>
        <br>
<!-- set table style -->
        <table class="table table-hover table-bordered table-striped table-condensed fixed">
            <thead>
            <tr class="padset"><font size="2">
<!-- set table header and column width -->
              <th scope="col" style="width: 10%"><u>Date</u></th>
              <th scope="col" style="width: 14%" ><u>Name</u></th>
              <th scope="col" style="width: 12%" ><u>Organizer</u></th>
              <th scope="col" style="width: 12%"><u>Place</u></th>
              <th scope="col" style="width: 18%"><u>Description</u></th>
              <th scope="col" style="width: 14%"><u>Website</u></th> 
              <th scope="col" style="width: 12%"><u>Remark</u></th>    
              <th scope="col" style="width: 8%"><u>Actions</u></th>                                    
            </font></tr>
            </thead>
            <tbody>
<!-- set table data -->
                <tr v-for="(event,index) in events" :key="event._id" class="text-left"><font size="2">
                  <td>{{ event.date }}</td>
                  <td>{{ event.name }}</td>
                  <td>{{ event.organizer }}</td>
                  <td>{{ event.place }}</td>
                  <td>{{ event.description }}</td>
                  <td>{{ event.website }}</td>
                  <td>{{ event.remark }}</td>                    
                  <td><router-link :to="{name: 'editEvent', params: { id: event._id }}" class="btn btn-warning btnStyle"><font size="1"><p class="center">Edit</p></font> </router-link>
                  <button class="btn btn-info btnStyle" @click.prevent="delEvent(event._id)"><font size="1"><p class="center">Delete</p></font></button></td>
                </font></tr>
            </tbody>
        </table>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        events: []
      }
    },
    created() {
// get data from uri to create page
      let uri = 'http://localhost:3000/api/events';
      this.axios.get(uri).then(response => {
//assign response data to events        
        this.events = response.data;
      });
    },
    methods: {
      delEvent(id)
      {
// get item data from uri to delete       
        let uri = `http://localhost:3000/api/delEvent/${id}`;
        this.axios.delete(uri).then(response => {
          console.log(response)
          this.$message({
              type: 'success',
              message: 'deletion succeeded: '  + id
          }) 
// refresh page after deletion
          this.$router.go(0);                                                   
        }).catch((err) => {
            console.log(err);
        });
      }
    }
  }
</script>

<style>

.fixed {
  table-layout: fixed
}

.btnStyle {
  height: 28px;
  width: 50px;
  padding: 0px;
  margin: 0px
}

.center {
  display: inline-block;  
  vertical-align: middle;
  text-align: center
}

.thbg {
    bg-color: black
}

</style>