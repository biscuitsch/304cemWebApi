<template>
  <div class="form-wrapper">
    <h1 style="color:#00CC00"><u>Add An Event</u></h1>
    <br>
    <form @submit.prevent="addEvent">
      <div class="row">
        <div class="col-md-12">
          <div class="form-group">
            <label>Date:</label>
            <input type="text" class="form-control" v-model="event.date" placeholder="Enter date">
          </div>
        </div>
        </div>
       <div class="row">       
        <div class="col-md-12">
          <div class="form-group">
            <label>Name:</label>
            <input type="text" class="form-control" v-model="event.name" placeholder="Enter name">
          </div>
        </div>
        </div>
       <div class="row">  
        <div class="col-md-12">
          <div class="form-group">
            <label>Organizer:</label>
            <input type="text" class="form-control" v-model="event.organizer" placeholder="Enter organizer">
          </div>
        </div>
        </div>
       <div class="row">  
        <div class="col-md-12">
          <div class="form-group">
            <label>Place:</label>
            <input type="text" class="form-control" v-model="event.place" placeholder="Enter place">
          </div>
        </div>
        </div>
       <div class="row">  
        <div class="col-md-12">
          <div class="form-group">
            <label>Description:</label>
            <input type="text" class="form-control" v-model="event.description" placeholder="Enter description">
          </div>
        </div>
        </div>
       <div class="row">  
        <div class="col-md-12">
          <div class="form-group">
            <label>Web Site:</label>
            <input type="text" class="form-control" v-model="event.website" placeholder="Enter website">
          </div>
        </div>
        </div>        
       <div class="row">          
        <div class="col-md-12">
          <div class="form-group">
            <label>Remark:</label>
            <input type="text" class="form-control" v-model="event.remark" placeholder="Enter remark">
          </div>
        </div>
        </div>
        <br />
        <div class="form-group">
          <button class="btn btn-success">Add Event</button>
        </div>
    </form>
  </div>
</template>

<script>
    export default {
        data(){
        return {
          event:{}
        }
    },
    methods: {   
      addEvent(){
// post data to uri to add record        
        let uri = 'http://localhost:3000/api/addEvent';
        this.axios.post(uri, this.event).then(() => {
// redirect to event list page after adding record         
          this.$router.push({name: 'events'});
        });
      }
    }
  }
</script>